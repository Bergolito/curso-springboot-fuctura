package br.com.fuctura.escola.controller.form;

import java.util.Optional;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;
import org.springframework.lang.Nullable;

import br.com.fuctura.escola.model.Professor;
import br.com.fuctura.escola.repository.ProfessorRepository;

public class AtualizacaoProfessorForm {

	@NotNull @NotEmpty  @Length(min = 5)
	private String nome;

	@Nullable
	private String email;

	@Nullable
	private Float valorHora;
	
	@Nullable
	private String certificados;
	
	@Nullable
	private String tipo;

	public String getNome() {
		return nome;
	}

	public String getEmail() {
		return email;
	}

	public String getTipo() {
		return tipo;
	}

	public Float getValorHora() {
		return valorHora;
	}

	public String getCertificados() {
		return certificados;
	}

	public Professor atualizar(Long id, ProfessorRepository professoresRepository) {
		Optional<Professor> professor = professoresRepository.findById(id);

		if(professor.isPresent()) {
			professor.get().setNome(this.nome);
			professor.get().setEmail(this.email);
			professor.get().setValorHora(this.valorHora);
			professor.get().setCertificados(this.certificados);
			professor.get().setTipo(this.tipo);

			return professor.get();
		}

		return null;
	}
}
