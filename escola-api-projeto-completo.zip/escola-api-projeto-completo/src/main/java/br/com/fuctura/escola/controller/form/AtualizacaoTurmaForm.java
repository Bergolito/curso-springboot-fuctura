package br.com.fuctura.escola.controller.form;

import java.util.Optional;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;

import br.com.fuctura.escola.model.Turma;
import br.com.fuctura.escola.repository.TurmaRepository;

public class AtualizacaoTurmaForm {

	@NotNull @NotEmpty  @Length(min = 5)
	private String nome;

	public String getNome() {
		return nome;
	}

	public Turma atualizar(Long id, TurmaRepository turmaRepository) {
		Optional<Turma> Turma = turmaRepository.findById(id);

		if(Turma.isPresent()) {
			Turma.get().setNome(this.nome);

			return Turma.get();
		}

		return null;
	}
}
