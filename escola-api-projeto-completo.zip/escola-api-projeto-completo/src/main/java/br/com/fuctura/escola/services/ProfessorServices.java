package br.com.fuctura.escola.services;


import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import br.com.fuctura.escola.model.Professor;
import br.com.fuctura.escola.repository.ProfessorRepository;

@Service
@Transactional
public class ProfessorServices {

	@Autowired
	private ProfessorRepository repositorioProfessor;

	public List<Professor> listarTodosProfessores() {
		return repositorioProfessor.findAll(Sort.by("id").ascending());
	}

}
