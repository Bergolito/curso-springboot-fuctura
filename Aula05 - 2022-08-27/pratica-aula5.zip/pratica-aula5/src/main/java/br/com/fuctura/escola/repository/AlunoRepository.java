package br.com.fuctura.escola.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import br.com.fuctura.escola.model.Aluno;

public interface AlunoRepository extends JpaRepository<Aluno, Long> {

	// métodos
	Page<Aluno> findByNome(String nomeAluno, Pageable paginacao);

	List<Aluno> findByCpf(String cpf);
}
