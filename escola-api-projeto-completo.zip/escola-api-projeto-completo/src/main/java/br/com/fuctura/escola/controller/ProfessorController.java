package br.com.fuctura.escola.controller;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletResponse;
import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.lowagie.text.DocumentException;

import br.com.fuctura.escola.controller.form.ProfessorForm;
import br.com.fuctura.escola.controller.form.AtualizacaoProfessorForm;
import br.com.fuctura.escola.dto.ProfessorDto;
import br.com.fuctura.escola.dto.DetalhesDoProfessorDto;
import br.com.fuctura.escola.model.Professor;
import br.com.fuctura.escola.report.ProfessorPDFExporter;
import br.com.fuctura.escola.repository.ProfessorRepository;
import br.com.fuctura.escola.services.ProfessorServices;
import io.swagger.v3.oas.annotations.Operation;

@RestController
@RequestMapping("/professores")
public class ProfessorController {

	@Autowired
	private ProfessorRepository professorRepository;

	@Autowired
	private ProfessorServices professorService;

	@GetMapping
	@Operation(summary = "listarProfessors", description = "listar os Professors da escola")
	public Page<ProfessorDto> listaProfessors(@RequestParam(required = false) String nomeProfessor,
			@PageableDefault(sort = "id", direction = Direction.ASC, page = 0, size = 10) Pageable paginacao) {

		if (nomeProfessor == null) {
			Page<Professor> Professors = professorRepository.findAll(paginacao);
			return ProfessorDto.converter(Professors);
		} else {
			Page<Professor> Professors = professorRepository.findByNome(nomeProfessor, paginacao);
			return ProfessorDto.converter(Professors);
		}
	}

	@PostMapping
	@Transactional
	public ResponseEntity<ProfessorDto> cadastrar(@RequestBody @Valid ProfessorForm form) {
		Professor Professor = form.converterDTO();
		professorRepository.save(Professor);

		return new ResponseEntity<ProfessorDto>(new ProfessorDto(Professor), HttpStatus.CREATED);
	}

	@GetMapping("/{id}")
	@Operation(summary = "detalhar", description = "detalha um Professor de acordo com o Id")
	public ResponseEntity<DetalhesDoProfessorDto> detalhar(@PathVariable Long id) {
		Optional<Professor> Professor = professorRepository.findById(id);
		if (Professor.isPresent()) {
			return ResponseEntity.ok(new DetalhesDoProfessorDto(Professor.get()));
		}

		return ResponseEntity.notFound().build();
	}

	@PutMapping("/{id}")
	@Transactional
	public ResponseEntity<ProfessorDto> atualizar(@PathVariable Long id, @RequestBody @Valid AtualizacaoProfessorForm form) {
		Optional<Professor> optional = professorRepository.findById(id);
		if (optional.isPresent()) {
			Professor Professor = form.atualizar(id, professorRepository);
			return ResponseEntity.ok(new ProfessorDto(Professor));
		}

		return ResponseEntity.notFound().build();
	}

	@DeleteMapping("/{id}")
	@Transactional
	public ResponseEntity<?> remover(@PathVariable Long id) {
		Optional<Professor> optional = professorRepository.findById(id);
		if (optional.isPresent()) {
			professorRepository.deleteById(id);
			return ResponseEntity.ok().build();
		}

		return ResponseEntity.notFound().build();
	}

	@GetMapping("/relatorio-pdf")
	public void exportarRelatorioPDF(HttpServletResponse response) throws DocumentException, IOException {
		response.setContentType("application/pdf");
		DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
		String currentDateTime = dateFormatter.format(new Date());

		String headerKey = "Content-Disposition";
		String headerValue = "attachment; filename=relatorio_professores_" + currentDateTime + ".pdf";
		response.setHeader(headerKey, headerValue);

		List<Professor> listaProfessors = professorService.listarTodosProfessores();

		ProfessorPDFExporter exporter = new ProfessorPDFExporter(listaProfessors);
		exporter.export(response);
	}

}
