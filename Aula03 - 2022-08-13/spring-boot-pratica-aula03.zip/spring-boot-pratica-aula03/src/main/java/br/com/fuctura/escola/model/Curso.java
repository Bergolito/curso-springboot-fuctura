package br.com.fuctura.escola.model;

public class Curso {

	private Long id;
	private String nome;
	private String requisitos;
	private Integer cargaHoraria;
	private Float preco;
}
