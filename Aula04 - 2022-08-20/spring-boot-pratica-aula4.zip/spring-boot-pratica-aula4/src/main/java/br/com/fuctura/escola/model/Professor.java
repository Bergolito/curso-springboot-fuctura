package br.com.fuctura.escola.model;

public class Professor {

	private Long id;
	private String cpf;
	private String nome;
	private String email;
	private Float valorHora;
	private String certificados;
	// TITULAR ou SUBSTITUTO
	private String tipo;
	

	
	
}
