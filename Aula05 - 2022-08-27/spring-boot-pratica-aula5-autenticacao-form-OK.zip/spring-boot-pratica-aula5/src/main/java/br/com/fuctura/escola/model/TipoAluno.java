package br.com.fuctura.escola.model;

public enum TipoAluno {
	
	CONVENCIONAL,
	MONITOR;

}
