package br.com.fuctura.escola.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import br.com.fuctura.escola.model.Aluno;

public interface AlunoRepository extends JpaRepository<Aluno, Long> {

	// métodos
	Page<Aluno> findByNome(String nomeAluno, Pageable paginacao);

	List<Aluno> findByCpf(String cpf);
	
    List<Aluno> findByEmailAndFone(String email, String fone);

    List<Aluno> findByEmailOrFone(String email, String fone);

    @Query("select a from Aluno a where a.email = ?1")
    List<Aluno> findByEmail(String email);

    @Query("select a from Aluno a where a.fone = ?1")
    List<Aluno> findByFone(String fone);	
}
