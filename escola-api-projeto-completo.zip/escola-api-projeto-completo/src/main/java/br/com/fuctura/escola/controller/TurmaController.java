package br.com.fuctura.escola.controller;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletResponse;
import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.lowagie.text.DocumentException;

import br.com.fuctura.escola.controller.form.AtualizacaoTurmaForm;
import br.com.fuctura.escola.controller.form.TurmaForm;
import br.com.fuctura.escola.dto.DetalhesDaTurmaDto;
import br.com.fuctura.escola.dto.TurmaDto;
import br.com.fuctura.escola.model.Turma;
import br.com.fuctura.escola.report.TurmaPDFExporter;
import br.com.fuctura.escola.repository.CursoRepository;
import br.com.fuctura.escola.repository.ProfessorRepository;
import br.com.fuctura.escola.repository.TurmaRepository;
import br.com.fuctura.escola.services.TurmaServices;
import io.swagger.v3.oas.annotations.Operation;

@RestController
@RequestMapping("/turmas")
public class TurmaController {

	@Autowired
	private TurmaRepository turmaRepository;

	@Autowired
	private CursoRepository cursoRepository;

	@Autowired
	private ProfessorRepository professorRepository;
	
	@Autowired
	private TurmaServices turmaService;

	@GetMapping
	@Operation(summary = "listarTurmas", description = "listar as Turmas da escola")
	public Page<TurmaDto> listaTurmas(@RequestParam(required = false) String nomeTurma,
			@PageableDefault(sort = "id", direction = Direction.ASC, page = 0, size = 10) Pageable paginacao) {

		if (nomeTurma == null) {
			Page<Turma> Turmas = turmaRepository.findAll(paginacao);
			return TurmaDto.converter(Turmas);
		} else {
			Page<Turma> Turmas = turmaRepository.findByNome(nomeTurma, paginacao);
			return TurmaDto.converter(Turmas);
		}
	}

	@PostMapping
	@Transactional
	public ResponseEntity<TurmaDto> cadastrar(@RequestBody @Valid TurmaForm form) {
		Turma Turma = form.converterDTO(professorRepository, cursoRepository);
		turmaRepository.save(Turma);

		return new ResponseEntity<TurmaDto>(new TurmaDto(Turma), HttpStatus.CREATED);
	}

	@GetMapping("/{id}")
	@Operation(summary = "detalhar", description = "detalha um Turma de acordo com o Id")
	public ResponseEntity<DetalhesDaTurmaDto> detalhar(@PathVariable Long id) {
		Optional<Turma> Turma = turmaRepository.findById(id);
		if (Turma.isPresent()) {
			return ResponseEntity.ok(new DetalhesDaTurmaDto(Turma.get()));
		}

		return ResponseEntity.notFound().build();
	}

	@PutMapping("/{id}")
	@Transactional
	public ResponseEntity<TurmaDto> atualizar(@PathVariable Long id, @RequestBody @Valid AtualizacaoTurmaForm form) {
		Optional<Turma> optional = turmaRepository.findById(id);
		if (optional.isPresent()) {
			Turma Turma = form.atualizar(id, turmaRepository);
			return ResponseEntity.ok(new TurmaDto(Turma));
		}

		return ResponseEntity.notFound().build();
	}

	@DeleteMapping("/{id}")
	@Transactional
	public ResponseEntity<?> remover(@PathVariable Long id) {
		Optional<Turma> optional = turmaRepository.findById(id);
		if (optional.isPresent()) {
			turmaRepository.deleteById(id);
			return ResponseEntity.ok().build();
		}

		return ResponseEntity.notFound().build();
	}

	@GetMapping("/relatorio-pdf")
	public void exportarRelatorioPDF(HttpServletResponse response) throws DocumentException, IOException {
		response.setContentType("application/pdf");
		DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
		String currentDateTime = dateFormatter.format(new Date());

		String headerKey = "Content-Disposition";
		String headerValue = "attachment; filename=relatorio_turmas_" + currentDateTime + ".pdf";
		response.setHeader(headerKey, headerValue);

		List<Turma> listaTurmas = turmaService.listarTodosTurmas();

		TurmaPDFExporter exporter = new TurmaPDFExporter(listaTurmas);
		exporter.export(response);
	}

}
