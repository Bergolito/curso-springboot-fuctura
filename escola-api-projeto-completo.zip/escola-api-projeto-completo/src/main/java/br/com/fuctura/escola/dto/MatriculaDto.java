package br.com.fuctura.escola.dto;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;
import org.springframework.data.domain.Page;

import br.com.fuctura.escola.model.Matricula;

public class MatriculaDto {

	@NotNull
	@NotEmpty
	@Length(min = 11, max = 11)
	private Long id;

	@NotNull
	@NotEmpty
	@Length(min = 5)
	private String nomeTurma;

	@NotNull
	@NotEmpty
	@Length(min = 5)
	private String nomeAluno;

	// Construtor
	public MatriculaDto(Matricula Matricula) {
		this.id = Matricula.getId();
		this.nomeTurma = Matricula.getTurma().getNome();
		this.nomeAluno = Matricula.getAluno().getNome();
	}

	public static Page<MatriculaDto> converter(Page<Matricula> matriculas) {
		return matriculas.map(MatriculaDto::new);
	}

	// getters aqui
	public Long getId() {
		return id;
	}

	public String getNomeTurma() {
		return nomeTurma;
	}

	public String getNomeAluno() {
		return nomeAluno;
	}


}
