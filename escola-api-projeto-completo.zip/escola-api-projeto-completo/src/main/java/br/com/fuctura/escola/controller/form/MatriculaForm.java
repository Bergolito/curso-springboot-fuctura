package br.com.fuctura.escola.controller.form;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import br.com.fuctura.escola.model.Matricula;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@AllArgsConstructor @NoArgsConstructor
public class MatriculaForm {

	@NotNull @NotEmpty 
	private Long id;

	public Matricula converterDTO() {
		Matricula matricula = new Matricula(id);
		return matricula;
	}

	// ... getters/setters
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	
}
