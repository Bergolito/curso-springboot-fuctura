package br.com.fuctura.escola.dto;

import br.com.fuctura.escola.model.Turma;

public class DetalhesDaTurmaDto {

	private Long id;
	private String nome;
	private Long idProfessor;
	private Long idCurso;
	private Integer cargaHoraria; 

	public DetalhesDaTurmaDto(Turma turma) {
		this.id = turma.getId();
		this.nome = turma.getNome();
		this.idProfessor= turma.getProfessor().getId();
		this.idCurso = turma.getCurso().getId();
		this.cargaHoraria= turma.getCargaHoraria();
	}

	public Long getId() {
		return id;
	}

	public String getNome() {
		return nome;
	}

	public Long getIdProfessor() {
		return idProfessor;
	}

	public Long getIdCurso() {
		return idCurso;
	}

	public Integer getCargaHoraria() {
		return cargaHoraria;
	}

}
