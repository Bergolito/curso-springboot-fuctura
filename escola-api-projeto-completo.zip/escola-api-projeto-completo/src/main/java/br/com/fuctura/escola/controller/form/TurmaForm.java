package br.com.fuctura.escola.controller.form;

import java.util.Optional;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;
import org.springframework.lang.Nullable;

import br.com.fuctura.escola.model.Curso;
import br.com.fuctura.escola.model.Professor;
import br.com.fuctura.escola.model.Turma;
import br.com.fuctura.escola.repository.CursoRepository;
import br.com.fuctura.escola.repository.ProfessorRepository;

public class TurmaForm {

	@NotNull @NotEmpty  @Length(min = 5)
	private String nome;

	@NotNull
	private Long idProfessor;
	
	@NotNull	
	private Long idCurso;
	
	@Nullable
	private Integer cargaHoraria; 
	
	public Turma converterDTO(ProfessorRepository professorRepository, CursoRepository cursoRepository) {
		//
		Optional<Professor> professor = professorRepository.findById(idProfessor);
		Optional<Curso> curso = cursoRepository.findById(idCurso);
		
		Turma turma = new Turma(nome, professor.get(), curso.get(), cargaHoraria);
		return turma;
	}

	public String getNome() {
		return nome;
	}

	public Long getIdProfessor() {
		return idProfessor;
	}

	public Long getIdCurso() {
		return idCurso;
	}

	public Integer getCargaHoraria() {
		return cargaHoraria;
	}

	// ... getters/setters

}
