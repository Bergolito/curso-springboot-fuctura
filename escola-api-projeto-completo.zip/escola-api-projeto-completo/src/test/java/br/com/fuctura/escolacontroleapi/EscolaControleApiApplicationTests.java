package br.com.fuctura.escolacontroleapi;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EscolaControleApiApplicationTests {

	//@Test
	void contextLoads() {
	}

}
