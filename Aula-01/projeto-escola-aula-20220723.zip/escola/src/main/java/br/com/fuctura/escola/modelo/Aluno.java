package br.com.fuctura.escola.modelo;

import java.time.LocalDate;

public class Aluno {

	private Long id;
	private String cpf;
	private String nome;
	private String email;
	private String fone;
	private LocalDate dataNascimento;
	// CONVENCIONAL, MONITOR
	private String tipo;
}
