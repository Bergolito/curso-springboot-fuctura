package br.com.fuctura.escola.controller;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletResponse;
import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.lowagie.text.DocumentException;

import br.com.fuctura.escola.controller.form.AtualizacaoMatriculaForm;
import br.com.fuctura.escola.controller.form.MatriculaForm;
import br.com.fuctura.escola.dto.DetalhesDaMatriculaDto;
import br.com.fuctura.escola.dto.MatriculaDto;
import br.com.fuctura.escola.model.Matricula;
import br.com.fuctura.escola.report.MatriculaPDFExporter;
import br.com.fuctura.escola.repository.AlunoRepository;
import br.com.fuctura.escola.repository.MatriculaRepository;
import br.com.fuctura.escola.repository.TurmaRepository;
import br.com.fuctura.escola.services.MatriculaServices;
import io.swagger.v3.oas.annotations.Operation;

@RestController
@RequestMapping("/matriculas")
public class MatriculaController {

	@Autowired
	private MatriculaRepository matriculaRepository;
	
	@Autowired
	private TurmaRepository turmaRepository;
	
	@Autowired
	private AlunoRepository alunoRepository;

	@Autowired
	private MatriculaServices matriculaService;

	@GetMapping
	@Operation(summary = "listarMatriculas", description = "listar os Matriculas da escola")
	public Page<MatriculaDto> listaMatriculas(@RequestParam(required = false) String nomeAluno,
			@PageableDefault(sort = "id", direction = Direction.ASC, page = 0, size = 10) Pageable paginacao) {

		if (nomeAluno == null) {
			Page<Matricula> Matriculas = matriculaRepository.findAll(paginacao);
			return MatriculaDto.converter(Matriculas);
		} else {
			Page<Matricula> Matriculas = matriculaRepository.findByAlunoNome(nomeAluno, paginacao);
			return MatriculaDto.converter(Matriculas);
		}
	}

	@PostMapping
	@Transactional
	public ResponseEntity<MatriculaDto> cadastrar(@RequestBody @Valid MatriculaForm form) {
		Matricula Matricula = form.converterDTO(turmaRepository, alunoRepository);
		matriculaRepository.save(Matricula);

		return new ResponseEntity<MatriculaDto>(new MatriculaDto(Matricula), HttpStatus.CREATED);
	}

	@GetMapping("/{id}")
	@Operation(summary = "detalhar", description = "detalha um Matricula de acordo com o Id")
	public ResponseEntity<DetalhesDaMatriculaDto> detalhar(@PathVariable Long id) {
		Optional<Matricula> Matricula = matriculaRepository.findById(id);
		if (Matricula.isPresent()) {
			return ResponseEntity.ok(new DetalhesDaMatriculaDto(Matricula.get()));
		}

		return ResponseEntity.notFound().build();
	}

	@PutMapping("/{id}")
	@Transactional
	public ResponseEntity<MatriculaDto> atualizar(@PathVariable Long id, @RequestBody @Valid AtualizacaoMatriculaForm form) {
		Optional<Matricula> optional = matriculaRepository.findById(id);
		if (optional.isPresent()) {
			Matricula Matricula = form.atualizar(id, matriculaRepository);
			return ResponseEntity.ok(new MatriculaDto(Matricula));
		}

		return ResponseEntity.notFound().build();
	}

	@DeleteMapping("/{id}")
	@Transactional
	public ResponseEntity<?> remover(@PathVariable Long id) {
		Optional<Matricula> optional = matriculaRepository.findById(id);
		if (optional.isPresent()) {
			matriculaRepository.deleteById(id);
			return ResponseEntity.ok().build();
		}

		return ResponseEntity.notFound().build();
	}

	@GetMapping("/relatorio-pdf")
	public void exportarRelatorioPDF(HttpServletResponse response) throws DocumentException, IOException {
		response.setContentType("application/pdf");
		DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
		String currentDateTime = dateFormatter.format(new Date());

		String headerKey = "Content-Disposition";
		String headerValue = "attachment; filename=relatorio_matriculas_" + currentDateTime + ".pdf";
		response.setHeader(headerKey, headerValue);

		List<Matricula> listaMatriculas = matriculaService.listarTodasMatriculas();

		MatriculaPDFExporter exporter = new MatriculaPDFExporter(listaMatriculas);
		exporter.export(response);
	}

}
