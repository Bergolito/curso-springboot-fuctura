/*
 * Cadastro de Usuários
 */ 
INSERT INTO USUARIO(nome, email, senha) VALUES('Aluno', 'aluno@escola.com', '$2a$10$pzGb4RsG6syepEiry9xGxuSX2oOKL8K6G9PO21VJkBquKpEtMSpVS');
INSERT INTO USUARIO(nome, email, senha) VALUES('Professor', 'prof@escola.com', '$2a$10$pzGb4RsG6syepEiry9xGxuSX2oOKL8K6G9PO21VJkBquKpEtMSpVS');

/*
 * Cadastro de Alunos
 */ 
INSERT INTO ALUNO (cpf, nome, email, fone, tipo) VALUES  
  ('11111111111', 'Alberto', 'aluno111@escola.com', '81 1234-5555', 'CONVENCIONAL');

INSERT INTO ALUNO (cpf, nome, email, fone, tipo) VALUES  
  ('22222222222', 'Bruno', 'aluno222@escola.com', '81 1234-5555', 'CONVENCIONAL');

INSERT INTO ALUNO (cpf, nome, email, fone, tipo) VALUES  
  ('33333333333', 'Carlos', 'aluno333@escola.com', '81 1234-5555', 'MONITOR');

INSERT INTO ALUNO (cpf, nome, email, fone, tipo) VALUES  
  ('44444444444', 'Daniel', 'aluno111@escola.com', '81 1234-5555', 'CONVENCIONAL');

INSERT INTO ALUNO (cpf, nome, email, fone, tipo) VALUES  
  ('55555555555', 'Emerson', 'aluno222@escola.com', '81 1234-5555', 'CONVENCIONAL');

INSERT INTO ALUNO (cpf, nome, email, fone, tipo) VALUES  
  ('66666666666', 'Fernando', 'aluno333@escola.com', '81 1234-5555', 'MONITOR');

INSERT INTO ALUNO (cpf, nome, email, fone, tipo) VALUES  
  ('77777777777', 'Guilherme', 'aluno111@escola.com', '81 1234-5555', 'CONVENCIONAL');

INSERT INTO ALUNO (cpf, nome, email, fone, tipo) VALUES  
  ('88888888888', 'Heitor', 'aluno222@escola.com', '81 1234-5555', 'CONVENCIONAL');

INSERT INTO ALUNO (cpf, nome, email, fone, tipo) VALUES  
  ('99999999999', 'José', 'aluno333@escola.com', '81 1234-5555', 'MONITOR');
  
INSERT INTO ALUNO (cpf, nome, email, fone, tipo) VALUES  
  ('44422233344', 'Paulo', 'aluno333@escola.com', '81 1234-5555', 'MONITOR');
  
INSERT INTO ALUNO (cpf, nome, email, fone, tipo) VALUES  
  ('55599944411', 'Roberto', 'aluno333@escola.com', '81 1234-5555', 'MONITOR');
  
  