package br.com.fuctura.escola.dto;

import br.com.fuctura.escola.model.Matricula;

public class DetalhesDaMatriculaDto {

	private Long id;

	public DetalhesDaMatriculaDto(Matricula matricula) {
		this.id = matricula.getId();
	}

	public Long getId() {
		return id;
	}

}
