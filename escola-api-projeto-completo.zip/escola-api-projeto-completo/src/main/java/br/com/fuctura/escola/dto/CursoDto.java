package br.com.fuctura.escola.dto;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;
import org.springframework.data.domain.Page;
import org.springframework.lang.Nullable;

import br.com.fuctura.escola.model.Curso;

public class CursoDto {

	@NotNull @NotEmpty @Length(min = 5)
	private String nome;

	@Nullable
	private String requisitos;

	@Nullable
	private Integer cargaHoraria;

	@Nullable 
	private Float preco;

	// Construtor
	public CursoDto(Curso curso) {
		this.nome = curso.getNome();
		this.requisitos = curso.getRequisitos();
		this.cargaHoraria = curso.getCargaHoraria();
		this.preco = curso.getPreco();
	}

	// converte Curso em CursoDto
	public static Page<CursoDto> converter(Page<Curso> cursos) {
		return cursos.map(CursoDto::new);
	}

	// getters aqui
	public String getNome() {
		return nome;
	}

	public String getRequisitos() {
		return requisitos;
	}

	public Integer getCargaHoraria() {
		return cargaHoraria;
	}

	public Float getPreco() {
		return preco;
	}

	
}
