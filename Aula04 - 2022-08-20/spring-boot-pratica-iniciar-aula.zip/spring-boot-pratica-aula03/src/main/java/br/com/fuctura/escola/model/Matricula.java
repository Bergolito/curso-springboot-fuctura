package br.com.fuctura.escola.model;

import java.time.LocalDateTime;

public class Matricula {

	private Long id;
	private Turma turma;
	private Aluno aluno;
	private LocalDateTime dataMatricula;
	
}
