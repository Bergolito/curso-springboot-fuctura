
INSERT INTO ALUNO (cpf, nome, email, fone, tipo) VALUES  
('11111111111', 'Huguinho', 'aluno111@escola.com', '81 1234-5555', 'CONVENCIONAL');

INSERT INTO ALUNO (cpf, nome, email, fone, tipo) VALUES  
('22222222222', 'Zezinho', 'aluno222@escola.com', '81 1234-5555', 'CONVENCIONAL');

INSERT INTO ALUNO (cpf, nome, email, fone, tipo) VALUES  
('33333333333', 'Luizinho', 'aluno333@escola.com', '81 1234-5555', 'MONITOR');
