package br.com.fuctura.escola.model;

public enum TipoProfessor {
	
	TITULAR,
	SUBSTITUTO;

}
