package br.com.fuctura.escola.controller;

import java.util.Optional;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import br.com.fuctura.escola.controller.form.AtualizacaoProfessorForm;
import br.com.fuctura.escola.controller.form.ProfessorForm;
import br.com.fuctura.escola.dto.DetalhesDoProfessorDto;
import br.com.fuctura.escola.dto.ProfessorDto;
import br.com.fuctura.escola.model.Professor;
import br.com.fuctura.escola.repository.ProfessoresRepository;

@RestController
@RequestMapping("/professores")
public class ProfessoresController {

	@Autowired
	private ProfessoresRepository professorRepository;
	
	@GetMapping
	public Page<ProfessorDto> listaProfessors(
			@RequestParam(required = false) String nomeProfessor,
			@PageableDefault(sort = "id", direction = Direction.ASC, page = 0, size = 10) Pageable paginacao) {
		
		if (nomeProfessor == null) {
			Page<Professor> professores = professorRepository.findAll(paginacao);
			return ProfessorDto.converter(professores);
		} else {
			Page<Professor> professores = professorRepository.findByNome(nomeProfessor, paginacao);
			return ProfessorDto.converter(professores);
		}
	}
	
	@PostMapping
	@Transactional
	public ResponseEntity<ProfessorDto> cadastrar(@RequestBody @Valid ProfessorForm form) {
		Professor professor = form.converterDTO();
		professorRepository.save(professor);
		
		return new ResponseEntity<ProfessorDto>(new ProfessorDto(professor), HttpStatus.CREATED);
	}	
	
	@GetMapping("/{id}")
	public ResponseEntity<DetalhesDoProfessorDto> detalhar(@PathVariable Long id) {
		Optional<Professor> professor = professorRepository.findById(id);
		if (professor.isPresent()) {
			return ResponseEntity.ok(new DetalhesDoProfessorDto(professor.get()));
		}
		
		return ResponseEntity.notFound().build();
	}
	
	@PutMapping("/{id}")
	@Transactional
	public ResponseEntity<ProfessorDto> atualizar(@PathVariable Long id, @RequestBody @Valid AtualizacaoProfessorForm form) {
		Optional<Professor> optional = professorRepository.findById(id);
		if (optional.isPresent()) {
			Professor Professor = form.atualizar(id, professorRepository);
			return ResponseEntity.ok(new ProfessorDto(Professor));
		}
		
		return ResponseEntity.notFound().build();
	}
	
	@DeleteMapping("/{id}")
	@Transactional
	public ResponseEntity<?> remover(@PathVariable Long id) {
		Optional<Professor> optional = professorRepository.findById(id);
		if (optional.isPresent()) {
			professorRepository.deleteById(id);
			return ResponseEntity.ok().build();
		}
		
		return ResponseEntity.notFound().build();
	}
	
}
