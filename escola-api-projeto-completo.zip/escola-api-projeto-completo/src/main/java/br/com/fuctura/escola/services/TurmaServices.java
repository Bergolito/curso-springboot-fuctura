package br.com.fuctura.escola.services;


import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import br.com.fuctura.escola.model.Turma;
import br.com.fuctura.escola.repository.TurmaRepository;

@Service
@Transactional
public class TurmaServices {

	@Autowired
	private TurmaRepository repositorioTurmas;

	public List<Turma> listarTodosTurmas() {
		return repositorioTurmas.findAll(Sort.by("id").ascending());
	}

}
