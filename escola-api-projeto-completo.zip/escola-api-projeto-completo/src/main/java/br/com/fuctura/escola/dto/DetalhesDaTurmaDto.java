package br.com.fuctura.escola.dto;

import br.com.fuctura.escola.model.Turma;

public class DetalhesDaTurmaDto {

	private Long id;
	private String nome;

	public DetalhesDaTurmaDto(Turma turma) {
		this.nome = turma.getNome();
	}

	public Long getId() {
		return id;
	}

	public String getNome() {
		return nome;
	}

}
