package br.com.fuctura.escola.controller.form;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;

import br.com.fuctura.escola.model.Turma;

public class TurmaForm {

	@NotNull @NotEmpty  @Length(min = 5)
	private String nome;

	public Turma converterDTO() {
		Turma turma = new Turma(nome);
		return turma;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	// ... getters/setters
	
}
