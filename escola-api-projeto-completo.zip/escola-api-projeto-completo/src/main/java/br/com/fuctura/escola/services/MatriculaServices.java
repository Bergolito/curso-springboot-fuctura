package br.com.fuctura.escola.services;


import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import br.com.fuctura.escola.model.Matricula;
import br.com.fuctura.escola.repository.MatriculaRepository;

@Service
@Transactional
public class MatriculaServices {

	@Autowired
	private MatriculaRepository repositorioMatriculas;

	public List<Matricula> listarTodasMatriculas() {
		return repositorioMatriculas.findAll(Sort.by("id").ascending());
	}

}
