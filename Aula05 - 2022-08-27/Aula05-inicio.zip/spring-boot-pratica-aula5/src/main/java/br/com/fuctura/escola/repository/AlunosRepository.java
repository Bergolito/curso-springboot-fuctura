package br.com.fuctura.escola.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import br.com.fuctura.escola.model.Aluno;

public interface AlunosRepository extends JpaRepository<Aluno, Long> {

	Page<Aluno> findByNome(String nomeAluno, Pageable paginacao);
}
