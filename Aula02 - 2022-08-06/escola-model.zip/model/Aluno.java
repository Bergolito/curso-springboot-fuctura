package br.com.fuctura.escola.model;


public class Aluno {

	private Long id;
	private String cpf;	
	private String nome;	
	private String email;
	private String fone;
	private String tipo = TipoAluno.CONVENCIONAL.toString();

	// Construtores aqui
	public Aluno() {
		//
	}

	// Métodos Getters e Setters aqui
	
}
