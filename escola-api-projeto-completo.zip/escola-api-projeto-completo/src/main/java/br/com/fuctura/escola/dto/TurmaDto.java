package br.com.fuctura.escola.dto;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;
import org.springframework.data.domain.Page;

import br.com.fuctura.escola.model.Turma;

public class TurmaDto {

	@NotNull
	@NotEmpty
	@Length(min = 5)
	private String nome;

	// Construtor
	public TurmaDto(Turma turma) {
		this.nome = turma.getNome();
	}

	public static Page<TurmaDto> converter(Page<Turma> turmas) {
		return turmas.map(TurmaDto::new);
	}

	// getters aqui
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	
	
		
}
