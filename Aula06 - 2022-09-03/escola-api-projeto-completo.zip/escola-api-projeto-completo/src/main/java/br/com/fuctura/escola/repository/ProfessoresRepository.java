package br.com.fuctura.escola.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import br.com.fuctura.escola.model.Professor;

public interface ProfessoresRepository extends JpaRepository<Professor, Long> {

	Page<Professor> findByNome(String nomeProfessor, Pageable paginacao);
}
