package br.com.fuctura.escola.dto;

import br.com.fuctura.escola.model.Professor;

public class DetalhesDoProfessorDto {

	private Long id;
	private String cpf;
	private String nome;
	private String email;
	private Float valorHora;
	private String certificados;
	private String tipo;

	public DetalhesDoProfessorDto(Professor professor) {
		this.id = professor.getId();
		this.cpf = professor.getCpf();
		this.nome = professor.getNome();
		this.email = professor.getEmail();
		this.valorHora = professor.getValorHora();
		this.certificados = professor.getCertificados();
		this.tipo = professor.getTipo().toString();
	}

	public Long getId() {
		return id;
	}

	public String getCpf() {
		return cpf;
	}

	public String getNome() {
		return nome;
	}

	public String getEmail() {
		return email;
	}

	public String getTipo() {
		return tipo;
	}

	public Float getValorHora() {
		return valorHora;
	}

	public String getCertificados() {
		return certificados;
	}
	
}
