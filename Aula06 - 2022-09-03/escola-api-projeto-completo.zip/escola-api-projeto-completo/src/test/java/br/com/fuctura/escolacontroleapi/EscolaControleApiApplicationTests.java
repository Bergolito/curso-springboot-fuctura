package br.com.fuctura.escolacontroleapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EscolaControleApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
