package br.com.fuctura.escola.controller.form;

import java.util.Optional;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.springframework.lang.Nullable;

import br.com.fuctura.escola.model.Aluno;
import br.com.fuctura.escola.model.Matricula;
import br.com.fuctura.escola.model.Turma;
import br.com.fuctura.escola.repository.AlunoRepository;
import br.com.fuctura.escola.repository.TurmaRepository;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@AllArgsConstructor @NoArgsConstructor
public class MatriculaForm {

	/*
	private Long id;
	private Turma turma;
	private Aluno aluno;
	private LocalDateTime dataMatricula;
	 */
	@NotNull  
	private Long idTurma;

	@NotNull  
	private Long idAluno;
	
	@Nullable  
	private String dataMatricula;

	public Matricula converterDTO(TurmaRepository turmaRepository, AlunoRepository alunoRepository) {
		//public Matricula(Long id, Turma turma, Aluno aluno, LocalDateTime dataMatricula) {
		//Matricula matricula = new Matricula(id);
		Optional<Turma> turma = turmaRepository.findById(idTurma);
		Optional<Aluno> aluno = alunoRepository.findById(idAluno);
		Matricula matricula = new Matricula(turma.get(), aluno.get(), null);
		return matricula;
	}

	// ... getters/setters
	public Long getIdTurma() {
		return idTurma;
	}

	public Long getIdAluno() {
		return idAluno;
	}

	public String getDataMatricula() {
		return dataMatricula;
	}
	
}

