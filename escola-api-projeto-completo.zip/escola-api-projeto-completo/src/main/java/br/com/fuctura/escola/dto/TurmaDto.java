package br.com.fuctura.escola.dto;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;
import org.springframework.data.domain.Page;
import org.springframework.lang.Nullable;

import br.com.fuctura.escola.model.Turma;

public class TurmaDto {

	private Long id;
	
	@NotNull
	@NotEmpty
	@Length(min = 5)
	private String nome;
	
	@NotNull
	private Long idProfessor;
	
	@NotNull
	private Long idCurso;
	
	@Nullable
	private Integer cargaHoraria; 

	// Construtor
	public TurmaDto(Turma turma) {
		this.id = turma.getId();
		this.nome = turma.getNome();
		this.idCurso = turma.getCurso().getId();
		this.idProfessor = turma.getProfessor().getId();
		this.cargaHoraria = turma.getCargaHoraria();
	}

	public static Page<TurmaDto> converter(Page<Turma> turmas) {
		return turmas.map(TurmaDto::new);
	}

	// getters aqui
	public Long getId() {
		return id;
	}

	public String getNome() {
		return nome;
	}

	public Long getIdProfessor() {
		return idProfessor;
	}

	public Long getIdCurso() {
		return idCurso;
	}

	public Integer getCargaHoraria() {
		return cargaHoraria;
	}
		
}
