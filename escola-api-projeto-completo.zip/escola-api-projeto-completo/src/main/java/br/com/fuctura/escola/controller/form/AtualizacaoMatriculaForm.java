package br.com.fuctura.escola.controller.form;

import java.util.Optional;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import br.com.fuctura.escola.model.Matricula;
import br.com.fuctura.escola.repository.MatriculaRepository;

public class AtualizacaoMatriculaForm {

	@NotNull @NotEmpty 
	private Long id;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Matricula atualizar(Long id, MatriculaRepository matriculaRepository) {
		Optional<Matricula> matricula = matriculaRepository.findById(id);

		if(matricula.isPresent()) {
			matricula.get().setId(id);;

			return matricula.get();
		}

		return null;
	}
}
